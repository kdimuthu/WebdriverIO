const { expect, browser, $ } = require('@wdio/globals')

describe('Login to system' , ()=>{

    it.only('Login with valid credentials' , async ()=>{
        //Open the browser
        await browser.url('https://demo.guru99.com/test/newtours/index.php')
        //Enter username
        await $('input[name="userName"]').setValue('kdimuthu')
        //Enter password
        await $('input[name="password"]').setValue('Dimuthu@123')
        //Click Submit button
        await $('input[name="submit"]').click()
        //Verify login success message
        await expect($('h3')).toHaveText('Login Successfully')

    })
})
