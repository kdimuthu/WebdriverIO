const LoginPage = require('../pages/loginpage')

describe('Page Object Model', () =>{

   it('Login Test', async () =>{

        //Open browser
    
        await browser.url('https://demo.guru99.com/test/newtours/index.php')

        await LoginPage.login("kdimuthu","Dimuthu@123")
   })

    
})