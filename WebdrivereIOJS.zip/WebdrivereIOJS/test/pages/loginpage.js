class LoginPage{

    get txt_Username(){
        return $('input[name="userName"]')
    }

    get txt_Password(){
        return $('input[name="password"]')
    }

    get btn_Submit(){
        return $('input[name="submit"]')
    }

    async login(username, password){

        //Enter username
        await this.txt_Username.setValue(username)

        //Enter password
        await this.txt_Password.setValue(password)

        //Click submit button
        await this.btn_Submit.click()


    }
}

module.exports = new LoginPage()